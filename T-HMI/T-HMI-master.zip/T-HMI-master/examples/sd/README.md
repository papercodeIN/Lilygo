SD TEST
========

The test found that only SD cards with a capacity of less than 32GB (including 32GB) are supported.
