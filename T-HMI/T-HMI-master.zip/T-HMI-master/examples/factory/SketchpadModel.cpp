#include "SketchpadModel.h"

SketchpadModel::SketchpadModel() {
}


SketchpadModel::~SketchpadModel() {
}